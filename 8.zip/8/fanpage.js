$("#Members").on("mouseover",function(){
  $("#Members").addClass("membershover");  
})

$("#Members").on("mouseleave",function(){
    $("#Members").removeClass("membershover");  
  })

  $("#songs").on("mouseover",function(){
    $("#songs").addClass("songsHover");  
  })
  
  $("#songs").on("mouseleave",function(){
      $("#songs").removeClass("songsHover");  
    })